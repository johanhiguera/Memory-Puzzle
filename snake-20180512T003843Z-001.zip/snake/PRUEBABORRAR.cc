#include <iostream>
#include <random>
struct pos {
int x;
int y;
};
int main(){
std::random_device rd;
pos card;
card.x=4;
card.y=4;
int a[card.x][card.y];
for(int i=0;i<card.x;i++){
    for(int j=0;j<card.y;j++){

        a[i][j]= (unsigned int) rd %((card.x*card.y)/2);
    std::cout<<a[i][j];
    }
    std::cout<<std::endl;
}

return 0;
}
